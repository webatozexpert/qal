  
  <?php $__env->startSection('content'); ?>

  <div class="page-breadcrumb">
    <div class="row">
      <div class="col-5 align-self-center">
        <h4 class="page-title">Create User</h4>
      </div>
      <div class="col-7 align-self-center">
        <div class="d-flex align-items-center justify-content-end">
          <a href="<?php echo e(URL('/all-user')); ?>">
            <button type="submit" class="btn btn-success mr-2"> <i class="fa fa-user-plus" aria-hidden="true"></i>All User </button>
          </a>
        </div>
      </div>
    </div>
  </div>
  <div class="content-wrapper">
    <div class="card">
      <div class="card-body">

        <div class="row">

          <div class="col-7 table-responsive">

            <h3 class="card-title text-center">User Registration</h3>

            <form action="<?php echo e(URL('/user/store')); ?>" method="POST" class="forms-sample">

              <?php echo e(csrf_field()); ?>    <!-- token -->

              <div class="form-group row">
                <label for="zoneCode" class="col-sm-3 col-form-label">User Name</label>
                <div class="col-sm-9" style="padding-left: 0;">
                  <input type="text" class="form-control" id="name" name="name" placeholder="User Name" autocomplete="off" >
                </div>
              </div>
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-semibold text-danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="form-group row">
                <label for="zoneName" class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-9" style="padding-left: 0;">
                  <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" autocomplete="off" >
                </div>
              </div>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-semibold text-danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="form-group row">
                <label for="zoneName" class="col-sm-3 col-form-label">User Role</label>
                <div class="col-sm-9" style="padding-left: 0;">
                  <select name="user_role" id="user_role" class="select2 form-control custom-select" style="width: 100%;" >
                    <option value="">Select</option>
                    <?php $__currentLoopData = $userrole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($rows->id); ?>"><?php echo e($rows->role_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <?php $__errorArgs = ['user_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-semibold text-danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="form-group row">
                <label for="zoneName" class="col-sm-3 col-form-label">User Group</label>
                <div class="col-sm-9" style="padding-left: 0;">
                  <select name="user_group" id="user_group" class="select2 form-control custom-select" style="width: 100%;" required="">
                    <option value="QAL">QAL</option>
                    <option value="QFL">QFL</option>
                    <option value="QIL">QIL</option>
                    <option value="QBL">QBL</option>
                    <option value="ABL">ABL</option>
                  </select>
                </div>
              </div>
              <?php $__errorArgs = ['user_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-semibold text-danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="form-group row">
                <label for="zoneName" class="col-sm-3 col-form-label">User Status</label>
                <div class="col-sm-9" style="padding-left: 0;">
                  <select name="status" id="status" class="select2 form-control custom-select" style="width: 100%;" >
                    <option value="1">Active</option>
                    <option value="2">Inactive</option>
                  </select>
                </div>
              </div>
              <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-semibold text-danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="form-group row">
                <label for="zoneName" class="col-sm-3 col-form-label">Password</label>
                <div class="col-sm-9" style="padding-left: 0;">
                  <input type="password" class="form-control" id="password" name="password" placeholder="Enter minimum 6 character password" autocomplete="off" >
                </div>
              </div>
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-semibold text-danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="form-group row">
                <label for="zoneName" class="col-sm-3 col-form-label">Confirm Password</label>
                <div class="col-sm-9" style="padding-left: 0;">
                  <input type="password" class="form-control" id="password" name="password_confirmation" placeholder="Enter confirm password" autocomplete="off" >
                </div>
              </div>
              <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-semibold text-danger"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              &nbsp;&nbsp;&nbsp;&nbsp;
              <div class="row">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body" style="padding: 0px;">
                      <div class="table-responsive">
                        <table class="table">
                          <thead>
                            <tr>
                              <th>Branch</th>
                              <th>Mark</th>
                             
                            </tr>
                          </thead>
                          <tbody>
                            <?php $sr=0; ?>
                            <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                             
                             <td><?php echo e($results->name); ?></td>
                              <td>
                                <input type="checkbox" name="branch_id[]" id="branch_id<?php echo e($sr); ?>" value="<?php echo e($results->id); ?>"></a>

                              </td>
                             
                            </tr>
                             <?php $sr++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="form-group row text-right">
                <div class="col-sm-12">
                  <button type="submit" class="btn btn-success mr-2">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('masterDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\qal\qal\resources\views/user/create.blade.php ENDPATH**/ ?>