<?php if($type==1): ?>

<select name="item_id" id="item_id" class="select2 form-control custom-select" style="width: 100%;" required="">
    <option value="">Select</option>
    <?php $__currentLoopData = $itemName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($rows->item_name.'_'.$rows->id.'_'.$rows->item_id); ?>"><?php echo e($rows->item_name.' | '.$rows->item_code); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<?php elseif($type==2): ?>
<?php echo e($quantity->quantity); ?>


<?php elseif($type==3): ?>

<select name="branch" id="branch" class="select2 form-control custom-select" style="width: 100%;" onchange="requisitionWiseBranch(this.value)">
    <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($rows->name.'_'.$rows->id); ?>" <?php if($rows->id==$branchReq->branch_id): ?> selected="" <?php endif; ?>>
        <?php echo e($rows->name); ?>

    </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<?php endif; ?><?php /**PATH D:\Github\qal\qal\resources\views/purchaseorder/requisitionWiseitemName.blade.php ENDPATH**/ ?>