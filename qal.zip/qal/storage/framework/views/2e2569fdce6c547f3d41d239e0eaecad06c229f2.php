<?php if($type==1): ?>

  <select name="subgroup_id" id="subgroup_id" class="select2 form-control custom-select" style="width: 100%;" required="">
    <option value="">Select</option>
    <?php $__currentLoopData = $subgroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($rows->id); ?>"><?php echo e($rows->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>

<?php elseif($type==2): ?>

  <select name="category" id="category" class="select2 form-control custom-select" style="width: 100%;" required="">
    
    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($rows->id); ?>"><?php echo e($rows->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  
<?php endif; ?><?php /**PATH D:\Github\qal\qal\resources\views/product/productSubgroup.blade.php ENDPATH**/ ?>