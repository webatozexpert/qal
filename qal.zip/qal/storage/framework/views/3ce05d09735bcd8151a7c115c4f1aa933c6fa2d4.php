<?php $__env->startSection('content'); ?>

<div class="page-breadcrumb">
  <div class="row">
    <div class="col-5 align-self-center">
      <h4 class="page-title">Update Money Receipt</h4>
    </div>
    <div class="col-7 align-self-center">
      <div class="d-flex align-items-center justify-content-end">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo e(URL('/dashboard')); ?>">Dashboard</a>
            </li>
            <li class="breadcrumb-item">
              <a href="<?php echo e(URL('/money-receipt')); ?>">Money Receipt</a>
            </li>

          </ol>
        </nav>
      </div>
    </div>
  </div>
</div>

<div class="container-fluid">
  <div class="card">
    <div class="card-body">

      <div class="row">
        <div class="col-12 table-responsive">
          <div class="card">
            <div class="card-body" style="padding: 0px;">
              <form action="<?php echo e(URL('/money-receipt-update')); ?>" method="POST" class="forms-sample">
                <?php echo e(csrf_field()); ?>    <!-- token -->

                <div class="form-group row">
                  <label for="zoneCode" class="col-sm-3 col-form-label">Money Receipt No</label>
                  <div class="col-sm-3" style="padding-left: 0;">
                    <input type="text" class="form-control" id="mrNo" name="mrNo" autocomplete="off" value="<?php echo e($edit->serial_no); ?>" readonly="">
                  </div>

                  <label for="zoneCode" class="col-sm-3 col-form-label">Money Receipt Date</label>
                  <div class="col-sm-3" style="padding-left: 0;">
                    <input type="text" class="form-control" id="fromDate" name="mrDate" autocomplete="off" value="<?php echo e(date('d-m-Y', strtotime($edit->added_date))); ?>">
                  </div>
                </div>


                <div class="form-group row">
                  <label for="zoneCode" class="col-sm-3 col-form-label">Bank</label>
                  <div class="col-sm-9" style="padding-left: 0;">
                    <select name="bankid" id="bankid" class="select2 form-control custom-select" style="width: 100%;" required="">
                      <option value="">Select Bank</option>
                      <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($bank->id); ?>" <?php if($edit->bank_id==$bank->id): ?> selected="" <?php endif; ?>><?php echo e($bank->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="zoneCode" class="col-sm-3 col-form-label">Agent</label>
                  <div class="col-sm-9" style="padding-left: 0;">
                    <select name="customerid" id="customerid" class="select2 form-control custom-select" style="width: 100%;" required="">
                      <option value="">Select Agent</option>
                      <?php $__currentLoopData = $allCustomer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allCustomers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($allCustomers->id); ?>" <?php if($edit->custid==$allCustomers->id): ?> selected="" <?php endif; ?>><?php echo e($allCustomers->name); ?> (<?php echo e($allCustomers->code); ?>)</option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="zoneCode" class="col-sm-3 col-form-label">Amount</label>
                  <div class="col-sm-9" style="padding-left: 0;">
                    <input type="number" class="form-control" id="amount" name="amount" placeholder="Amount" autocomplete="off" value="<?php echo e($edit->amount); ?>">
                  </div>
                </div>

                <div class="form-group row">
                  <label for="zoneName" class="col-sm-3 col-form-label">Note</label>
                  <div class="col-sm-9" style="padding-left: 0;">
                    <textarea name="note" class="form-control" placeholder="Note"><?php echo e($edit->note); ?></textarea>
                  </div>
                </div>                
                
                <input type="hidden" name="id" id="id" value="<?php echo e($edit->id); ?>">

                <div class="form-group row text-right">
                  <div class="col-sm-12">
                    <button type="submit" class="btn btn-success mr-2">Update</button>
                  </div>
                </div>

              </form>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\qal\qal\resources\views/mr/mrEdit.blade.php ENDPATH**/ ?>