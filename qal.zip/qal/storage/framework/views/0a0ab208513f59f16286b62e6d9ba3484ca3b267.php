<?php $__env->startSection('content'); ?>

<div class="page-breadcrumb">
  <div class="row">
    
    <div class="col-7 align-self-center">
      <div class="d-flex align-items-center justify-content-end">
       <h4 class="page-title"> Requisition Approved List</h4>
      </div>
    </div>
  </div>
</div>

<div class="container-fluid">

  <?php if(Session::has('success')): ?>     
  <div class="alert alert-success alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

  </div>

  <?php endif; ?>

  <div class="card">
    <div class="card-body">

      <div class="row">
        <div class="col-12 table-responsive">
          <div class="card">
            <div class="card-body" style="padding: 0px;">
                <div class="table-responsive">
                <table id="zero_config" class="table table-hover table-striped table-bordered">
                  <thead>
                    <tr>
                     
                      <th style="width:10%;">Branch</th>
                      <th style="width:10%;">Requisition No</th>
                      <th style="width:10%;">Posting Date</th>
                      <th style="width:10%;">Required Date</th>
                      <th style="width:10%;">Prepared By</th>
                       <th style="width:10%;">Item Group</th>
                      <th style="width:10%;">Memo No</th>
                     
                      <th style="width:10%;">Approved Type</th>
                     
                      <th style="width:05%;">Action</th>
                     
                    </tr>
                  </thead>                 
                  <tbody>
                  <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($results->bname); ?></td>
                      
                      <td><a href="<?php echo e(URL('/requisition-print/'.$results->id)); ?>" target="_blank" title="print"><?php echo e($results->requisition_no); ?></a>
                      </td>
                      <td><?php echo e($results->postingDate); ?></td>
                      <td><?php echo e($results->requiredDate); ?></td>
                      <td><?php echo e($results->created_by); ?></td>
                      <td><?php echo e($results->item_group); ?></td>
                      <td><?php echo e($results->memo_no); ?></td>
                  
                     <td>
                                                
                        <?php if($results->status=='0'): ?>
                       <span style="font-size:10px;" >Pending</span>
                       
                       <?php elseif($results->status=='1'): ?>
                       <span style="font-size:10px;" >Approved</span>
                       <?php elseif($results->status=='2'): ?>
                       <span style="font-size:10px;" >Confirm</span>
                       <?php elseif($results->status=='3'): ?>
                       <span style="font-size:12px;" >Order Confirm</span>

                       <?php endif; ?>
                    </td>
                    
                     <td><a href="<?php echo e(URL('/requisition-print/'.$results->id)); ?>"  target="_blank" title="print" class="btn btn-primary btn-sm"> <i class="fa fa-print" ></i>Preview</a>
                      </td>&nbsp;&nbsp;
                      <?php if($results->status=='0'): ?>
                      <td><a href="<?php echo e(URL('/requisition-edit/'.$results->id)); ?>" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a>&nbsp;&nbsp;
                     
                      <a href="<?php echo e(URL('/requisition-delete/'.$results->id)); ?>" title="delete"><i class="fa fa-trash" aria-hidden="true"></i></a>
                      </td>

                      <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\qal\qal\resources\views/requisition/orderConfirmList.blade.php ENDPATH**/ ?>