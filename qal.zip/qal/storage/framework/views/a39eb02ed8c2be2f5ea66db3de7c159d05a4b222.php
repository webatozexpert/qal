<?php $__env->startSection('content'); ?>

<div class="page-breadcrumb">
  <div class="row">
    <div class="col-5 align-self-center">
      <h4 class="page-title">Money Receipt</h4>
    </div>
    <div class="col-7 align-self-center">
      <div class="d-flex align-items-center justify-content-end">
        <a href="<?php echo e(URL('/new-money-receipt')); ?>">
          <button type="submit" class="btn btn-success mr-2"> <i class="fa fa-user-plus" aria-hidden="true"></i> New Money Receipt</button>
        </a>
      </div>
    </div>
  </div>
</div>


<div class="container-fluid">

  <?php if(Session::has('success')): ?>     
  <div class="alert alert-success alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

  </div>

  <?php endif; ?>

  <div class="card">
    <div class="card-body">

      <div class="row">
        <div class="col-12 table-responsive">
          <div class="card">
            <div class="card-body" style="padding: 0px;">
              <div class="table-responsive">
                <table id="zero_config" class="table table-hover table-striped table-bordered">
                  <thead>
                    <tr>
                      <th>Zone</th>
                      <th>Agent Name</th>
                      <th>Amount</th>
                      <th>Bank</th>
                      <th>Received Date</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($results->zname); ?></td>
                      <td><?php echo e($results->cname); ?> (<?php echo e($results->ccode); ?>)</td>
                      <td><?php echo e($results->amount); ?></td>
                      <td><?php echo e($results->bname); ?></td>
                      <td><?php echo e($results->added_date); ?></td>
                      <td><a href="<?php echo e(URL('/money-receipt-edit/'.$results->id)); ?>" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a> &nbsp;&nbsp;
                      <a href="<?php echo e(URL('/money-receipt-pdf/'.$results->id)); ?>" title="Print"><i class="fa fa-print" aria-hidden="true"></i></a>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\qal\qal\resources\views/mr/mrMaster.blade.php ENDPATH**/ ?>