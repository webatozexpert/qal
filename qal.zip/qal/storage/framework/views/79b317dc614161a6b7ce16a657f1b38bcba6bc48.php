<?php $__env->startSection('content'); ?>
<div class='container-fluid'>
	<div class='row'>
		<div class='col-12' style="text-align: right;float: right;">
			<img src='<?php echo e(URL::asset('resources/assets/images/printer.png')); ?>' width="20" height="20" onclick="printDiv()" style="cursor: pointer;" title="Print">
		</div>
	</div>

	<div class='card' id="section-to-print">
		<div class='card-body'>
			<div ]lass='row'>
				<div class='col-12 table-responsive'>
					<div class='card'>
						<div class='card-body' style='padding: 0px;'>

							<div class='table-responsive'>
								<table class='table' cellspacing="0">
									<tr>
										<td valign='top'><img src='<?php echo e(URL::asset('resources/assets/images/fav.png')); ?>' width='100' height='50'></td>
										<td valign='top' align='center' style='padding-top: 8px; width: 400px;'><h2><b> Quality Aquabreeds Limited </b></h2>
											<span style='border: 1px solid #000; padding: 5px 10px; margin-top: 20px;'><b> DELIVERY ORDER </b></span>
										</td>
										<td>CUSTOMER COPY <br />
											<b>Head Office :</b> <br />
											House 14, Road 7, Sector 4 <br />
											Uttara Dhaka-1230 <br />
											Tel : 58956024 (5 Lines) <br />
											Fax : 58956025, 58953019 <br /><br />
											<b> Farm :</b>
										Narkali, Krishnopur, Kahalu, Bogura</td>
									</tr>
								</table>

								<table class='table' cellspacing="0">
									<tr>
										<td>
											<table id='table' class='table-responsive' width='100%' cellspacing="0">
												<tr>
													<td style='width: 150px'>Delivery Order No</td>
													<td style='width: 300px'>: <?php echo e($result->delivery_order_no); ?></td>
												</tr>
												
												<tr>
													<td>Name of Agent</td>
													<td style=''>: <?php echo e($result->cname); ?></td>
												</tr>
												<tr>
													<td>Address</td>
													<td style=''>: <?php echo e($result->address); ?></td>
												</tr>
											</table>
										</td>
										<td style='width: 30px;'>&nbsp;</td>
										<td>
											<table id='table' class='table-responsive' width='100%' cellspacing="0">
												<tr>
													<td style='width: 150px'>D.O.Date</td>
													<td style='width: 150px'>: <?php echo e(date('d-m-Y', strtotime($result->do_date))); ?></td>
												</tr>
												
												<tr>
													<td>Agent Code</td>
													<td style=''>: <?php echo e($result->ccode); ?></td>
												</tr>
												<tr>
													<td>Delivery Point</td>
													<td style=''>: <?php echo e($result->delivery_point); ?></td>
												</tr>
											</table>
										</td>
									</tr>
								</table>


								<table class='table table-bordered' cellspacing="0">
									<thead>
										<tr>
											<td class='text-center' style='vertical-align: middle;'>Sl.</td>
											<td class='text-center' style='vertical-align: middle;'>Description</td>
											<td style='padding: 0px; background-color: #FFF;'>
												<table class='table' style='border: 0px !important; margin-bottom: 0px;' cellspacing="0">
													<tr>
														<td colspan='3' class='text-center' style='vertical-align: middle;'>Quality</td>
													</tr>
													<tr>
														<td class='text-center' width="100">Pcs/Box</td>
														<td class='text-center' width="100">No. Box</td>
														<td class='text-center' width="100">Total</td>
													</tr>
												</table>
											</td>
											<td class='text-center' style='vertical-align: middle;'>Remarks</td>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td class='text-center'>1</td>
											<td>Hybrid Monosex Telapia Fry</td>
											<td style='padding: 0px;'>
												<table class='table' style='margin-bottom: 0px;' cellspacing="0">
													<tr>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"><?php echo e(number_format($result->hybrid_monosex_tilapia_qty,0)); ?> </td>
													</tr>
												</table>
											</td>
											<td class="text-center">Pcs</td>
										</tr>
										<tr>
											<td class='text-center'>2</td>
											<td>Complementary</td> 
											<td style='padding: 0px;'>
												<table class='table' style='margin-bottom: 0px;' cellspacing="0">
													<tr>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"><?php echo e(number_format($result->tilapia_complementary_qty,0)); ?> </td>
													</tr>
												</table>
											</td>
											<td class="text-center">Pcs</td>
										</tr>

										<tr>
											<td class='text-center'>3</td>
											<td>Hybrid Monosex Pungas Fry</td>
											<td style='padding: 0px;'>
												<table class='table' style='margin-bottom: 0px;' cellspacing="0">
													<tr>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"><?php echo e(number_format($result->hybrid_monosex_pungas_qty,0)); ?> </td>
													</tr>
												</table>
											</td>
											<td class="text-center">Pcs</td>
										</tr>
										<tr>
											<td class='text-center'>4</td>
											<td>Complementary</td> 
											<td style='padding: 0px;'>
												<table class='table' style='margin-bottom: 0px;' cellspacing="0">
													<tr>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"><?php echo e(number_format($result->pungas_complementary_qty,0)); ?> </td>
													</tr>
												</table>
											</td>
											<td class='text-center'>Pcs</td>
										</tr>
										<tr>
											<td class='text-center'></td>
											<td class="text-center"><b>Total</b></td> 
											<td style='padding: 0px;'>
												<table class='table' style='margin-bottom: 0px;' cellspacing="0">
													<tr>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"></td>
														<td class='text-center' width="100"><b> <?php echo e(number_format(($result->hybrid_monosex_tilapia_qty + $result->tilapia_complementary_qty + $result->hybrid_monosex_pungas_qty + $result->pungas_complementary_qty),0)); ?> </b> </td>
													</tr>
												</table>
											</td>
											<td class="text-center"><b> Pcs </b></td>
										</tr>
									</tbody>
								</table>
								<p>&nbsp;</p>
								<table class='table' style='border-bottom: 0px;'>
									<thead>
										<tr>
											<td width='41%'><b>Issued by :</b></td>
											<td width='40%'><b> Verified by : </b></td>
											<td><b> Approved by : </b></td>
										</tr>
										<tr>
											<td>Name :</td>
											<td>Name :</td>
											<td>Name :</td>
										</tr>
										<tr>
											<td>Desig :</td>
											<td>Desig :</td>
											<td>Desig :</td>
										</tr>
									</thead>
								</table>

							</div>


						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\qal\qal\resources\views/order/orderPdf.blade.php ENDPATH**/ ?>