<?php if($type==1): ?>

<select name="item_name" id="item_name" class="select2 form-control custom-select" style="width: 100%;" required="">
    <option value="">Select</option>
    <?php $__currentLoopData = $itemName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($rows->item_name.'_'.$rows->id); ?>"><?php echo e($rows->item_name.' | '.$rows->item_code); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>

<?php elseif($type==2): ?>
<?php echo e($unit->item_unit_id); ?>

<!-- <select name="unit" id="unit" class="select2 form-control custom-select" style="width: 100%;" required="">
    <option value="">Select</option>
    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($rows->id); ?>"><?php echo e($rows->item_unit_id); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>

   -->
<?php endif; ?><?php /**PATH D:\Github\qal\qal\resources\views/requisition/requisitionItemName.blade.php ENDPATH**/ ?>