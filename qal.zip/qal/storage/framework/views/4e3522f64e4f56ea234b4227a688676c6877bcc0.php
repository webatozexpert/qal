<?php $__env->startSection('content'); ?>

<div class="page-breadcrumb">
  <div class="row">
    <div class="col-5 align-self-center">
      <h4 class="page-title">All User List</h4>
    </div>
    <div class="col-7 align-self-center">
      <div class="d-flex align-items-center justify-content-end">
        <a href="<?php echo e(URL('/user/create')); ?>">
          <button type="submit" class="btn btn-success mr-2"> <i class="fa fa-user-plus" aria-hidden="true"></i>User Create</button>
        </a>
      </div>
    </div>
  </div>
</div>


<div class="container-fluid">

  <?php if(Session::has('success')): ?>     
  <div class="alert alert-success alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

  </div>

  <?php endif; ?>

  <div class="card">
    <div class="card-body">

      <div class="row">
        <div class="col-12 table-responsive">
          <div class="card">
            <div class="card-body" style="padding: 0px;">
              <div class="table-responsive">
                <table  class="table table-hover table-striped table-bordered">
	                  <thead>
	                    <tr>
		                      <th style="width:15%;" >SL No</th>
		                      <th style="width:10%;" >Name</th>
		                      <th style="width:20%;" >Email</th>
		                      <th style="width:15%;" >Type</th>
		                      <th style="width:10%;" >User Role</th>
		                      <th style="width:10%;" >Status</th>
		                      <th style="width:10%;" >Action</th>
	                    </tr>
	                  </thead>
                   <tbody>
	                  <?php $__currentLoopData = $allusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alluser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    <tr>
	                      <td><?php echo e($alluser->id); ?></td>
	                      <td><?php echo e($alluser->name); ?></td>
	                      <td><?php echo e($alluser->email); ?></td>
	                      <td><?php echo e($alluser->type); ?></td>
	                      
	                     <td><?php echo e($alluser->role_name); ?></td>
	                  
	                     <td>
	                                                
	                        <?php if($alluser->status=='1'): ?>
	                       <span >Active</span>
	                       <?php elseif($alluser->status=='2'): ?>
	                       <span >Inactive</span>
	                      
	                       <?php endif; ?>
	                    </td>

	                     <td>

	                     &nbsp;
	                   
	                      <a href="<?php echo e(URL('/user-edit/'.$alluser->id)); ?>" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i></a>&nbsp;
	                     
	                      <a href="<?php echo e(URL('/user-delete/'.$alluser->id)); ?>" title="delete"><i class="fa fa-trash" aria-hidden="true"></i></a>
	                      </td>
	                     
	                    </tr>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\qal\qal\resources\views/user/alluser.blade.php ENDPATH**/ ?>